#include<iostream>
#include<list>
#include<sys/time.h>
using namespace std;
    

list<string> generateParenthesis(int n) { //vector컨테이너 대신 list컨테이너를 사용하였습니다.
    if (!n) return {""};
    list<string> parens;
    #pragma omp parallel for
    for (int i = 0; i < n; i++) {
        for (string inner : generateParenthesis(i)) {
            for (string outer : generateParenthesis(n - 1 - i)) {
                parens.push_back('(' + inner + ')' + outer);
            }
        }
    }
    return parens;
}

int main(){
    float sum = 0;
    for (int i = 0; i < 100; i++)
    {
        struct timeval stime,etime,gap;

        gettimeofday(&stime,NULL);
        generateParenthesis(10);
        gettimeofday(&etime,NULL);

        gap.tv_sec = etime.tv_sec - stime.tv_sec;
        gap.tv_usec = etime.tv_usec - stime.tv_usec;

        if(gap.tv_usec < 0){
            gap.tv_sec = gap.tv_sec-1; 
            gap.tv_usec = gap.tv_usec + 1000000;
        }
        sum += gap.tv_usec;
    }
    cout << sum/100 << endl;
}