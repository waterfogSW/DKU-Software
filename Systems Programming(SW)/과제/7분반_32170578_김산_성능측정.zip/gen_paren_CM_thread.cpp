#include<iostream>
#include<vector>
#include<omp.h>
#include<sys/time.h>
using namespace std;
    

vector<string> generateParenthesis(int n) {
    if (!n) return {""};

    vector<string> parens, inner, outer;
    int i = 0;
#pragma omp parallel //멀티 스레드를 생성합니다.
    {
    #pragma omp single private(i) //i는 for loop의 iterator로 사용되므로 Thread별로 독립적으로 사용하게 합니다.
    for (int i = 0; i < n; i++) {
        #pragma omp task shared(inner) 
        inner = generateParenthesis(i); //#1
        #pragma omp task shared(outer)
        outer = generateParenthesis(n - 1 - i); //#2
        #pragma omp taskwait //작업큐에 들어간 #1, #2 코드가 완료될 때까지 현재위치에서 기다립니다. 
        for (int j = 0; j < inner.size(); ++j) {
            for (int k = 0; k < outer.size(); ++k) {
                parens.push_back("(" + inner[j] + ")" + outer[k]);
            }
        }
    }
    }
    return parens;
}

int main(){
    float sum = 0;
    for (int i = 0; i < 100; i++)
    {
        struct timeval stime,etime,gap;

        gettimeofday(&stime,NULL);
        generateParenthesis(10);
        gettimeofday(&etime,NULL);

        gap.tv_sec = etime.tv_sec - stime.tv_sec;
        gap.tv_usec = etime.tv_usec - stime.tv_usec;

        if(gap.tv_usec < 0){
            gap.tv_sec = gap.tv_sec-1; 
            gap.tv_usec = gap.tv_usec + 1000000;
        }
        sum += gap.tv_usec;
    }
    cout << sum/100 << endl;
}